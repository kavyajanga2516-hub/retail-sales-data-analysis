"""Run end-to-end retail sales analysis and save summaries/charts."""
from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from clean import load_and_clean

def main():
    project = Path(__file__).resolve().parents[1]
    df = load_and_clean(project / "data/raw/retail_sales.csv")
    processed = project / "data/processed"
    figures = project / "outputs/figures"
    processed.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    df.to_csv(processed / "clean_sales.csv", index=False)

    monthly = df.groupby("month", as_index=False)["sales_inr"].sum()
    product = (df.groupby("product_name", as_index=False)["sales_inr"].sum()
                 .sort_values("sales_inr", ascending=False))
    category = (df.groupby("category", as_index=False)["sales_inr"].sum()
                  .sort_values("sales_inr", ascending=False))
    region = (df.groupby("region", as_index=False)["sales_inr"].sum()
                .sort_values("sales_inr", ascending=False))
    channel = (df.groupby("channel", as_index=False)["sales_inr"].sum()
                 .sort_values("sales_inr", ascending=False))
    for name, table in [("monthly_sales",monthly),("product_sales",product),
                        ("category_sales",category),("region_sales",region),
                        ("channel_sales",channel)]:
        table.to_csv(processed / f"{name}.csv", index=False)

    kpis = {
        "dataset_type": "synthetic practice data",
        "rows_analyzed": int(len(df)),
        "total_sales_inr": round(float(df["sales_inr"].sum()), 2),
        "unique_order_lines": int(df["order_id"].nunique()),
        "units_sold": int(df["quantity"].sum()),
        "average_line_sales_inr": round(float(df["sales_inr"].mean()), 2),
        "top_product_by_sales": str(product.iloc[0]["product_name"]),
        "top_category_by_sales": str(category.iloc[0]["category"]),
        "top_region_by_sales": str(region.iloc[0]["region"]),
        "top_channel_by_sales": str(channel.iloc[0]["channel"])
    }
    (processed / "kpi_summary.json").write_text(json.dumps(kpis,indent=2),encoding="utf-8")

    sns.set_theme(style="whitegrid")
    plt.figure(figsize=(10,5))
    sns.lineplot(data=monthly,x="month",y="sales_inr",marker="o")
    plt.title("Monthly Net Sales"); plt.xlabel("Month"); plt.ylabel("Sales (INR)")
    plt.xticks(rotation=45); plt.tight_layout()
    plt.savefig(figures/"monthly_sales.png",dpi=160); plt.close()

    for data, x, title, filename in [
        (product.head(10),"product_name","Top Products by Sales","top_products.png"),
        (category,"category","Sales by Category","sales_by_category.png"),
        (region,"region","Sales by Region","sales_by_region.png"),
        (channel,"channel","Sales by Channel","sales_by_channel.png")]:
        plt.figure(figsize=(9,5))
        sns.barplot(data=data,x="sales_inr",y=x)
        plt.title(title); plt.xlabel("Sales (INR)"); plt.ylabel("")
        plt.tight_layout(); plt.savefig(figures/filename,dpi=160); plt.close()

    print(json.dumps(kpis,indent=2))
    print(f"\nTables saved in {processed}; charts saved in {figures}")

if __name__ == "__main__":
    main()
