"""Load and validate retail sales data."""
from pathlib import Path
import pandas as pd

REQUIRED = {
    "order_id", "order_date", "region", "channel", "product_id",
    "product_name", "category", "quantity", "unit_price_inr",
    "discount_rate", "sales_inr"
}

def load_and_clean(path):
    df = pd.read_csv(path)
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    df = df.copy()
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    numeric = ["quantity", "unit_price_inr", "discount_rate", "sales_inr"]
    for col in numeric:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["order_id", "order_date", "quantity",
                           "unit_price_inr", "discount_rate", "sales_inr"])
    df = df.drop_duplicates()
    df = df[df["quantity"] > 0]
    df = df[df["unit_price_inr"] >= 0]
    df = df[df["discount_rate"].between(0, 1)]
    df["sales_inr"] = (df["quantity"] * df["unit_price_inr"] *
                       (1 - df["discount_rate"])).round(2)
    df["month"] = df["order_date"].dt.to_period("M").astype(str)
    return df

if __name__ == "__main__":
    project = Path(__file__).resolve().parents[1]
    cleaned = load_and_clean(project / "data/raw/retail_sales.csv")
    out = project / "data/processed/clean_sales.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    cleaned.to_csv(out, index=False)
    print(f"Saved {len(cleaned)} cleaned records to {out}")
