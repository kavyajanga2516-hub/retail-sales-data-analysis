# Findings report

> Reminder: current bundled data is synthetic. Replace this disclaimer only if you switch to a documented real dataset.

## Executive summary
- Total sales:
- Units sold:
- Highest-sales product:
- Highest-sales category:
- Strongest region:

## Questions and evidence
1. Monthly sales pattern:
2. Product/category performance:
3. Regional/channel differences:
4. Data quality limitations:

## Recommendations
- Recommendation 1:
- Recommendation 2:

## Limitations
- Synthetic practice data
- Revenue only; no cost/profit fields
- Observed differences do not establish causes
