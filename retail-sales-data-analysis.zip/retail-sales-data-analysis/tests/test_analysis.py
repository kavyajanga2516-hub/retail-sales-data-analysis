import sys
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from clean import load_and_clean

def test_sales_are_recalculated():
    row = {
        "order_id":["x"],"order_date":["2025-01-01"],"region":["South"],
        "channel":["Online"],"product_id":["p"],"product_name":["item"],
        "category":["Test"],"quantity":[2],"unit_price_inr":[100],
        "discount_rate":[0.1],"sales_inr":[999]
    }
    result = load_and_clean(pd.DataFrame(row) if False else _write_temp(row))
    assert result.iloc[0]["sales_inr"] == 180

def _write_temp(row):
    import tempfile
    path = Path(tempfile.gettempdir()) / "retail_analysis_test.csv"
    pd.DataFrame(row).to_csv(path,index=False)
    return path
