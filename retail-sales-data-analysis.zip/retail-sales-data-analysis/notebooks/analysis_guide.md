# Analysis guide

Run `python src/analyze.py` from the repository root.

Suggested exploration:
1. Inspect `data/raw/retail_sales.csv` with `head()`, `info()`, and `describe()`.
2. Check missing values, duplicate rows, date coverage, and valid discount ranges.
3. Compare monthly net sales.
4. Rank products and categories by sales.
5. Compare sales across region and channel.
6. Explain why revenue alone does not establish profitability.

Optional notebook starter:
```python
import pandas as pd
df = pd.read_csv("../data/raw/retail_sales.csv", parse_dates=["order_date"])
df.head()
```
